package com.example.demo;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface C3MasterRepo extends MongoRepository<C3Master, String> {

}
