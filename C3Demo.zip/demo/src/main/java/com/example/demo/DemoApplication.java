
package com.example.demo;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.opencsv.CSVWriter;

@SpringBootApplication
public class DemoApplication  implements CommandLineRunner{

	@Autowired
	private C3MasterRepo repository;
	
	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}


	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		List<C3Master> l= repository.findAll();
		List<String> po=new ArrayList<>();
		File file = new File("/home/shivang/Documents/C3Collection.csv");
		FileWriter outputfile = new FileWriter(file);
		//List<String[]> data = new ArrayList<String[]>();
        // create CSVWriter object filewriter object as parameter
        //CSVWriter writer = new CSVWriter(outputfile);
		String DO_format="";
		for(C3Master c3: l) {
			
			String po_no=c3.getPurchaseOrderNumber();
			String[] split_po=po_no.split(",");
			if((c3.getCurrent_WorkflowStateName_ID().equals("Arrived")) || (c3.getCurrent_WorkflowStateName_ID().equals("In Door")) 
					|| (c3.getCurrent_WorkflowStateName_ID().equals("Refused"))){
				if(c3.getSite_ExternalReference().length()==1) {
					String append_O= "0"+c3.getSite_ExternalReference();
					 DO_format="DO"+append_O;
				}
				
				if(c3.getSite_ExternalReference().length()==2) {
					DO_format="DO"+c3.getSite_ExternalReference();
				}
				
				for(String s: split_po) {
					System.out.println(s +" Current Workflow Id : "+c3.getCurrent_WorkflowStateName_ID()+ "Site_External Reference: " + DO_format);
				}
				
			}
			
//	        data.add(new String[] {"PO Number", "Current_WorkflowStateName_ID", "Site_ExternalReference" });
//	        data.add(new String[] {c3.getPurchaseOrderNumber(), c3.getCurrent_WorkflowStateName_ID(), DO_format} );
//			writer.writeAll(data);
		}
		
        
		//writer.close();
        
        
	}
}
	